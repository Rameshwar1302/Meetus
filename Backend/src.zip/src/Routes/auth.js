import { Router } from "express";
import {login, register} from "../controllers/auth.js";


const router = Router();

router.route("/login").post(login);
router.route("/register").post(register);
router.route("/register");
router.route("/add_activity");
router.route("/get_allActivity");


export default router;